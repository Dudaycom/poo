﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ranking
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pessoa  Pessoa = new Pessoa();
            //ler os dados da pessoa
            Console.Write("Digite seu nome: ");
            Pessoa.Nome = Console.ReadLine();
            Console.Write("Digite seu email: ");
            Pessoa.Email = Console.ReadLine();
            Console.Write("Digite o seu ano de nascimento: ");
            Pessoa.AnoNascimento = Convert.ToInt32(Console.ReadLine());
            
            //mostrar na tela 
            Pessoa.ExibirIdade();
   
            Console.ReadKey();
        }
       
    }
}
