﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ranking
{
    internal class Pessoa
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public int AnoNascimento { get; set; }
        public void ExibirDados()
        {
            Console.WriteLine();
            Console.WriteLine("Nome: " + Nome);
            Console.WriteLine("Email: " + Email);
            Console.WriteLine("Data de nascimento: " + AnoNascimento);
        }
        public void ExibirIdade()
        {
            int AnoAtual = DateTime.Now.Year;
            Console.WriteLine("Você possui possui {1} anos", this.Nome, (AnoAtual - this.AnoNascimento));
        }
        
    }
}
